//
//  Prueba.swift
//  222
//
//  Created by CEDAM09 on 07/11/23.
//

import SwiftUI

struct Prueba: View {
    var body: some View {
        Image(systemName: "person.fill")
        Text("Hola mirim")
    }
}

#Preview {
    Prueba()
}
